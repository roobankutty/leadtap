import { Request, Response } from "express";
import { createLead } from "../services/lead.service";
import { asyncHandler } from "../utils/asyncHandler";

export const submitLead = asyncHandler(
  async (req: Request, res: Response) => {
    const result = await createLead(req.body);

    res.status(201).json(result);
  }
);