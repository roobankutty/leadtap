import { Request, Response } from "express";
import { getAllLeads } from "../services/leadStorage.service";
import { getProperties } from "../services/wordpress.service";

// GET /api/admin/leads
export async function fetchLeads(req: Request, res: Response) {
  const leads = await getAllLeads();

  res.json({
    success: true,
    total: leads.length,
    data: leads,
  });
}

// GET /api/admin/dashboard
export async function dashboard(req: Request, res: Response) {
  const leads = await getAllLeads();

  const propertyResult = await getProperties();

  const recentLeads = [...leads]
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() -
        new Date(a.createdAt).getTime()
    )
    .slice(0, 5);

  res.json({
    totalProperties: propertyResult.total,
    totalLeads: leads.length,
    recentLeads,
  });
}