import logger from "../utils/logger";
import { sendLeadNotification } from "./email.service";

export interface Lead {
  propertyId: number;
  name: string;
  email: string;
  phone: string;
  message: string;
}

export async function createLead(lead: Lead) {

  logger.info("New Lead Received", {
    propertyId: lead.propertyId,
    name: lead.name,
    email: lead.email,
  });

  try {
    await sendLeadNotification(lead);
    logger.info("Lead notification email sent successfully");
  } catch (error) {
    logger.error("Failed to send lead notification email", error);

    // Don't stop the API if email fails.
    // CRM integration will still be added later.
  }

  return {
    success: true,
    message: "Lead submitted successfully",
    lead,
  };
}