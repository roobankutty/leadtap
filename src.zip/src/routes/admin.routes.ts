import express from "express";
import { dashboard, fetchLeads } from "../controllers/admin.controller";

const router = express.Router();
router.get("/test", (req, res) => {
  res.send("Admin routes working");
});
router.get("/dashboard", dashboard);
router.get("/leads", fetchLeads);

export default router;