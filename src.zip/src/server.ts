import "dotenv/config";
import express from "express";
import cors from "cors";
import swaggerUi from "swagger-ui-express";

import swaggerSpec from "./config/swagger";
import propertyRoutes from "./routes/property.routes";
import taxonomyRoutes from "./routes/taxonomy.routes";
import leadRoutes from "./routes/lead.routes";
import webhookRoutes from "./routes/webhook.routes";
import adminRoutes from "./routes/admin.routes";

import { errorHandler } from "./middleware/errorHandler";
import logger from "./utils/logger";
import { requestLogger } from "./middleware/requestLogger";
import helmet from "helmet";
import compression from "compression";

const app = express();
console.log("Admin routes imported:", adminRoutes);
// Middleware
app.use(cors());
app.use(express.json());

// Health Check
app.get("/", (req, res) => {
    res.status(200).json({
        success: true,
        service: "Property Backend API",
        version: "1.0.0",
        status: "Running",
        timestamp: new Date().toISOString()
    });
});

// Routes
app.use("/api/properties", propertyRoutes);
app.use("/api/taxonomies", taxonomyRoutes);
app.use("/api/leads", leadRoutes);
app.use("/api/admin", adminRoutes);
// CRM Hooks
app.use("/api/webhook", webhookRoutes);

// Swagger Documentation
app.use(
    "/api-docs",
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec)
);

// Global Error Handler
app.use(errorHandler);

app.use(requestLogger);

app.use(helmet());

app.use(compression());

console.log("MAIL_HOST:", process.env.MAIL_HOST);
console.log("MAIL_PORT:", process.env.MAIL_PORT);

const PORT = process.env.PORT || 5000;

app._router?.stack?.forEach((layer: any) => {
  if (layer.route) {
    console.log(layer.route.path);
  } else if (layer.name === "router") {
    layer.handle.stack.forEach((handler: any) => {
      if (handler.route) {
        console.log("Router:", handler.route.path);
      }
    });
  }
});

// Start Server
app.listen(PORT, () => {
    logger.info(`🚀 Server started at http://localhost:${PORT}`);
    logger.info(`🌐 WordPress GraphQL: ${process.env.WORDPRESS_GRAPHQL}`);
});

